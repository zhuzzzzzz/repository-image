/* no test data */
const void* epicsRtemsFSImage = 0;
