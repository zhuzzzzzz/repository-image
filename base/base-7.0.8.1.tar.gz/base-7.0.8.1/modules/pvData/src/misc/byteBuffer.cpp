/*
 * Copyright information and license terms for this software can be
 * found in the file LICENSE that is included with the distribution
 */
/**
 *  @author mse
 */

#define epicsExportSharedSymbols
#include <pv/byteBuffer.h>
