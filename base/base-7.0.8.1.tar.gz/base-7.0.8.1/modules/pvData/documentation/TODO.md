TODO
===========

doxygen
-------

There is a lot of public code that does not have doxygen tags.

valueAlarm
---------

normativeTypes.html describes valueAlarm only for a value field that has type
double.
The implementation also supports all the numeric scalar types.
