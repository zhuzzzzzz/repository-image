/*
 * BACnetEnum.cpp
 *
 *  Created on: Jul 12, 2018
 *      Author: 8w4
 */

#include <BACnetEnum.h>

BACnetEnum::BACnetEnum() {
	// TODO Auto-generated constructor stub

}

BACnetEnum::~BACnetEnum() {
	// TODO Auto-generated destructor stub
}

