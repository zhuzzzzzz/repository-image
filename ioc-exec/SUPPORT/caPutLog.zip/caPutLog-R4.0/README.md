Documentation is [here](https://github.com/epics-modules/caPutLog/blob/master/docs/index.rst).
