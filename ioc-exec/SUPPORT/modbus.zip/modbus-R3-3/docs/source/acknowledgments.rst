Acknowledgments
---------------

The **modbus** package is based on the `modtcp and plctcp
packages <http://isacwserv.triumf.ca/epics/modtcp/TRIUMFmodtcp.html>`__
written by Rolf Keitel from Triumf. The **modtcp** package was
originally converted to Linux by Ivan So from NSLS. **modbus** was
extensively re-written for conversion to EPICS 3.14 and to use the EPICS
asyn module. It now contains little of the original **modtcp** code, but
retains much of the original architecture.
